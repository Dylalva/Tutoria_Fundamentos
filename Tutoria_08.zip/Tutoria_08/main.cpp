#include<iostream>
#include<sstream>
#include<string>
#include "Reloj.h"
using namespace std;

int main (int argc, char *argv[]) {
//	Fecha a(16, 9, 2025);
//	Fecha b(a);
//	cout << b.toString();
//	
//	//=========================================
//	
//	Tiempo aa(14, 02, 0);
//	Tiempo bb;
//	cout << aa.toString() << endl;
//	cout << bb.toString() << endl;
	
	Fecha fecha(16, 9, 2025);
	Tiempo tiempo(14, 36, 15);
	
	Reloj reloj(fecha, tiempo);
	int cant = 0;
	Tiempo alarma(15,0,0);
	reloj.setAlarma(alarma);
	while(cant < 3700 * 24){
		reloj.avanzarTiempo();
		cant++;
	}
	cout << reloj.toString();
	return 0;
}

