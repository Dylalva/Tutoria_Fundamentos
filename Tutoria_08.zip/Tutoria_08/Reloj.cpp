#include "Reloj.h"

Reloj::Reloj(Fecha f, Tiempo t) {
	fecha  = Fecha(f);
	tiempo = t;
	alarma = Tiempo(-1, -1, -1);
}

Reloj::Reloj() {
	fecha  = Fecha(16, 9, 2025);
	tiempo = Tiempo(14, 40, 41);
}

void Reloj::avanzarTiempo() {
	if (tiempo.avanzarTiempo()) {
		fecha.avanzarFecha();
	}
	if (activarAlarma()) {
		cout << "Alarma activada\n";
		cout << toString();
		system("pause");
	}
}

void Reloj::setAlarma(Tiempo al) {
	alarma = al;
}

bool Reloj::activarAlarma() {
	if (alarma.getHora() == -1) {
		return false;
	}
	return alarma.getHora() == tiempo.getHora() &&
		alarma.getMinutos() == tiempo.getMinutos() &&
		alarma.getSegundos() == tiempo.getSegundos();
}

string Reloj::toString() {
	stringstream ss;
	ss << "Reloj.\nFecha: " << fecha.toString()
		<< "\nHora: " << tiempo.toString() << endl;
	return ss.str();
}
